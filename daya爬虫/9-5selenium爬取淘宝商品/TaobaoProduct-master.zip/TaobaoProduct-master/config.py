MONGO_URL = 'localhost'
MONGO_DB = 'taobao'
MONGO_COLLECTION = 'products'

KEYWORD = 'ipad'

MAX_PAGE = 100

SERVICE_ARGS = ['--load-images=false', '--disk-cache=true']
